import React from "react";

// Using concise arrow syntax. When there's single expression on the right
// hand side, you can omit the return keyword. It's implied.
const Home = () => <h1>Home</h1>;

export default Home;
