import React from "react";

const PageNotFound = () => {
  return <h1>Oops! Houston, we have a problem. Insert fail whale here...</h1>;
};
export default PageNotFound;
