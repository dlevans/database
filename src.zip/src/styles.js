const styles = {
  brandColor: "#FF8F00"
};

export default styles;
